package con.simple.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.simple.db.DbConnection;

public class AuthenticationService {

	public Connection connection = DbConnection.getConnection();

	public Boolean isAuthenticated(String username, String password) {
		try {
			PreparedStatement ps = connection
					.prepareStatement("SELECT username,password FROM login1 WHERE username = ? AND password = ?");
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
		
			if (rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}

}
