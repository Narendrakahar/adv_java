package com.simple.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnection {

	public static Connection getConnection() {
		try {
			
			//put the connector jar in the lib dir 
			// path : webapp/WEB-INF/lib
			//inbuilt method
			 Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection connection = DriverManager.getConnection("jdbc:mysql://128.66.203.247:3306/msc3it13", "msc3it13", "sumo@123");
			
			System.out.println("Connected Successfully");
			return connection;
		}catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return null;
	}
	
}
